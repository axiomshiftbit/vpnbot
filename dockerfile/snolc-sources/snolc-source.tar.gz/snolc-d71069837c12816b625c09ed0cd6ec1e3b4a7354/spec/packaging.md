# packaging

`snolpkg` installs immutable native module content from HTTPS Git or an
absolute local Git path.

```text
snolpkg add -b <git-url> <module-name>
snolpkg add -s <git-url> <module-name>
snolpkg del <owner/name@version>
snolpkg template <owner/name@version> --role <role> --output <path>
```

Set `SNOLPKG_ROOT` to an absolute package directory. Copy `config/snolpkg.toml`
and `config/sources.toml` from the `snolpkg` repository there before the first
install.

## publication

The installer reads `snolpkg/<module>.toml` and its detached `.toml.sig` from a
single pinned `snolc-modules` commit through gix object access. It does not
check out the publication tree or run Git filters.

The strict manifest names package, authors, license, package version,
`wire_version`, classes, family, roles, platform capabilities, role template
source paths, entry, exact dependencies, source revision, toolchain, Cargo
package, and artifacts.

Each template lists its artifact targets. Every platform target and role pair
maps to one template. The installed target selects the template, so adapter-tun
emits Linux native mode on Linux and Android fd mode on Android.

Each artifact declares target triple, minimum ISA, minimum glibc or Android
API, HTTPS URL, byte size, SHA-256, and source-build output. The detached
Ed25519 signature covers the source TOML bytes. `sources.toml` supplies the
trusted public key. A key inside the package has no authority.

## binary install

Binary mode performs these operations:

1. lock the package root;
2. read and verify the publication;
3. verify exact installed dependencies;
4. download into a fresh staging directory;
5. enforce response length, byte count, and SHA-256;
6. extract regular files within configured limits;
7. verify the library and declared templates;
8. move content into its content-addressed immutable store;
9. replace the package lock atomically.

Archives may contain regular files and directories. The extractor rejects
absolute paths, parent traversal, links, devices, duplicate paths, setuid or
setgid bits, too many files, and byte-limit overflow.

## source install

Source mode checks out the exact signed source revision with gix, then runs:

```text
cargo +<toolchain> build --release --locked --package <package> --target <target>
```

The process uses argument vectors, not a shell. It copies the declared output,
role templates, project license, and notices into staging. Missing Cargo,
toolchain, source path, build output, or template fails. Source mode does not
download a binary fallback. Building package source executes untrusted build
code and is not a sandbox.

## store and deletion

The store path contains source fingerprint, owner, name, version, target, and
library content hash. A lock records the exact canonical library and store
paths. The engine verifies package identity and content hash before loading.
It never resolves `latest` or accesses the network.

Deletion checks every lock for an exact reverse dependency. It moves the store
entry to staging before removing the lock and restores it if lock removal
fails. Deletion does not remove module state or user configuration.

## templates and updates

`template` copies `templates/<role>.toml` to a new path and refuses overwrite.
An update installs another immutable content hash and atomically changes the
lock. It leaves user configuration untouched. A running engine keeps its loaded
library until a managed restart.

## proxy and offline behavior

Git, artifact HTTP, and Cargo inherit uppercase and lowercase `HTTP_PROXY`,
`HTTPS_PROXY`, `ALL_PROXY`, and `NO_PROXY`. An invalid explicit proxy returns an
error and does not attempt a direct connection.

Offline mode rejects any HTTPS Git or artifact access. An offline bundle must
contain the publication, signature, lock inputs, and artifacts or vendored
source needed by the selected mode.

## official packages

Ten signed manifests live under `snolc-modules/snolpkg/`. Each release manifest
binds artifacts to one clean source commit. Each archive carries Unlicense and
third-party dependency notices. Release checks compare archive size and SHA-256
to each signed row before upload.

`tools/package-release.py` consumes a checkout at that revision and explicit
prebuilt target directories. It writes deterministic archives, updates signed
artifact rows, binds every manifest to the clean checkout commit, and signs each
manifest with the release Ed25519 key. Run
`tools/verify-release.py <dist>` before upload. A second package run must produce
byte-identical archives.

Each repository packages its own product. Core archives contain the `snolc`
binary, C header, Unlicense and dependency notices. The module repository
publishes one signed archive per module and target. The `snolpkg` repository
publishes the installer. The snolcNG repository publishes desktop binaries and
the Android APK.

`tools/release-inventory.py` refuses a dirty checkout, derives the configured
Ed25519 public key from the private release key, and records every asset plus
the exact `Cargo.lock` dependency set. It writes and verifies detached
signatures for `release-inventory.json` and `SHA256SUMS`.

## failure behavior

A signature, hash, size, target, dependency, path, extraction, build, or move
error leaves the previous lock and store content available. Staging cleanup
does not rewrite a loaded library. The installer never raises privileges.
